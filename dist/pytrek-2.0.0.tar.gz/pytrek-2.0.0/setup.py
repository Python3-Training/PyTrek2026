# Works, yet beta.toml over-installs the .gsdict files?
#
from __future__ import unicode_literals
from distutils.core import setup
from setuptools import find_packages, find_namespace_packages

setup(name='PyTrek',
      author="Randall Nagy",
      version="2026.05.30",
      description="PyTrek 9000",
      author_email="r.a.nagy@gmail.com",
      url="http://soft9000.com",
      download_url="https://github.com/Python3-Training/PyTrek",
      platforms=["Windows", "Linux", "Solaris", "Mac OS-X"],
      packages=find_namespace_packages())
